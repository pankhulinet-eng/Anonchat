type UserId = number;

interface SpamRecord {
  count: number;
  firstAt: number;
  warnedAt?: number;
}

const spamMap = new Map<UserId, SpamRecord>();
const WINDOW_MS = 10_000;
const MAX_MESSAGES = 8;

export function checkSpam(userId: UserId): boolean {
  const now = Date.now();
  const record = spamMap.get(userId);

  if (!record || now - record.firstAt > WINDOW_MS) {
    spamMap.set(userId, { count: 1, firstAt: now });
    return false;
  }

  record.count++;
  if (record.count > MAX_MESSAGES) {
    return true;
  }
  return false;
}

export function resetSpam(userId: UserId): void {
  spamMap.delete(userId);
}
