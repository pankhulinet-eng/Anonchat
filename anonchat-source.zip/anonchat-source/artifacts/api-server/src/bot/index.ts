import { Telegraf, Markup, type Context } from "telegraf";
import { message } from "telegraf/filters";
import { db } from "@workspace/db";
import {
  usersTable,
  sessionsTable,
  reportsTable,
  likesTable,
} from "@workspace/db";
import { eq, and, sql, gt, count, gte } from "drizzle-orm";
import { logger } from "../lib/logger";
import { addToQueue, removeFromQueue, findPartner, getQueueLength, isInQueue } from "./queue";
import {
  setSession,
  getSession,
  removeSession,
  hasSession,
  getActiveSessionsCount,
} from "./sessions";
import { containsStopWord, containsAdContent, censorText } from "./stopwords";
import { checkSpam } from "./antispam";

const ADMIN_IDS: number[] = (process.env.ADMIN_IDS || "")
  .split(",")
  .map(Number)
  .filter(Boolean);

export function createBot(): Telegraf {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) throw new Error("TELEGRAM_BOT_TOKEN is not set");

  const bot = new Telegraf(token);

  async function ensureUser(ctx: Context): Promise<typeof usersTable.$inferSelect | null> {
    const from = ctx.from;
    if (!from) return null;

    const existing = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.telegramId, from.id))
      .limit(1);

    if (existing.length > 0) {
      return existing[0];
    }

    const [created] = await db
      .insert(usersTable)
      .values({
        telegramId: from.id,
        username: from.username ?? null,
      })
      .returning();

    return created;
  }

  async function isBanned(userId: number): Promise<boolean> {
    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.telegramId, userId))
      .limit(1);

    if (!user) return false;
    if (user.banPermanent) return true;
    if (user.banUntil && user.banUntil > new Date()) return true;
    return false;
  }

  async function endSession(userId: number, reason: "stop" | "next" | "partner_left"): Promise<number | null> {
    const session = getSession(userId);
    if (!session) return null;

    const partnerId = session.partner;
    const sessionId = session.sessionId;

    removeSession(userId);
    removeSession(partnerId);

    await db
      .update(sessionsTable)
      .set({ isActive: false, endedAt: new Date() })
      .where(eq(sessionsTable.id, sessionId));

    return partnerId;
  }

  async function startSearch(sendMsg: (text: string) => Promise<unknown>, userId: number): Promise<void> {
    if (await isBanned(userId)) {
      await sendMsg("🚫 Вы заблокированы и не можете использовать бота.");
      return;
    }

    if (hasSession(userId)) {
      await sendMsg("💬 Вы уже в диалоге. Используйте /next или /stop.");
      return;
    }

    if (isInQueue(userId)) {
      await sendMsg("🔍 Вы уже в очереди поиска.");
      return;
    }

    const partnerId = findPartner(userId);

    if (partnerId !== null) {
      const [session] = await db
        .insert(sessionsTable)
        .values({ user1Id: userId, user2Id: partnerId })
        .returning();

      setSession(userId, { sessionId: session.id, partner: partnerId, startedAt: new Date() });
      setSession(partnerId, { sessionId: session.id, partner: userId, startedAt: new Date() });

      await db
        .update(usersTable)
        .set({ totalChats: sql`${usersTable.totalChats} + 1` })
        .where(eq(usersTable.telegramId, userId));

      await db
        .update(usersTable)
        .set({ totalChats: sql`${usersTable.totalChats} + 1` })
        .where(eq(usersTable.telegramId, partnerId));

      const connectMsg =
        "🎉 Собеседник найден! Начинайте общение.\n\n" +
        "Команды:\n" +
        "/next — найти нового собеседника\n" +
        "/stop — завершить общение\n" +
        "/report — пожаловаться\n" +
        "/like — поставить лайк";

      await sendMsg(connectMsg);
      await bot.telegram.sendMessage(partnerId, connectMsg);
    } else {
      addToQueue(userId);
      const inQueue = getQueueLength();
      await sendMsg(
        `🔍 Ищем собеседника... В очереди: ${inQueue} чел.\n\n` +
        "Используйте /stop чтобы отменить поиск."
      );
    }
  }

  bot.start(async (ctx) => {
    await ensureUser(ctx);
    await ctx.reply(
      "👋 Добро пожаловать в анонимный чат!\n\n" +
      "Здесь вы можете общаться анонимно с людьми со всего мира.\n\n" +
      "Команды:\n" +
      "/find — найти собеседника\n" +
      "/next — следующий собеседник\n" +
      "/stop — остановить\n" +
      "/profile — настроить профиль\n" +
      "/stats — статистика\n" +
      "/report — пожаловаться\n" +
      "/like — поставить лайк\n" +
      "/help — помощь",
      Markup.keyboard([
        [Markup.button.text("🔍 Найти собеседника")],
        [Markup.button.text("📊 Статистика"), Markup.button.text("👤 Профиль")],
      ]).resize()
    );
  });

  bot.help(async (ctx) => {
    await ctx.reply(
      "📖 Помощь\n\n" +
      "/find — найти собеседника\n" +
      "/next — закончить текущий диалог и найти следующего\n" +
      "/stop — выйти из режима поиска/общения\n" +
      "/report — пожаловаться на собеседника\n" +
      "/like — поставить лайк собеседнику\n" +
      "/profile — настроить своё описание\n" +
      "/stats — статистика бота\n\n" +
      "⚠️ Правила:\n" +
      "• Запрещены ссылки и реклама\n" +
      "• Запрещена нецензурная лексика\n" +
      "• 3 жалобы = автоматический бан"
    );
  });

  bot.command("find", async (ctx) => {
    const user = await ensureUser(ctx);
    if (!user) return;
    await startSearch((text) => ctx.reply(text), ctx.from.id);
  });

  bot.hears("🔍 Найти собеседника", async (ctx) => {
    const user = await ensureUser(ctx);
    if (!user) return;
    await startSearch((text) => ctx.reply(text), ctx.from.id);
  });

  bot.command("stop", async (ctx) => {
    const userId = ctx.from.id;
    removeFromQueue(userId);

    if (!hasSession(userId)) {
      await ctx.reply("✅ Вы не в диалоге и не в очереди поиска.");
      return;
    }

    const partnerId = await endSession(userId, "stop");

    await ctx.reply(
      "🛑 Диалог завершён.\n\nНажмите «🔍 Найти собеседника» чтобы начать новый.",
      Markup.keyboard([
        [Markup.button.text("🔍 Найти собеседника")],
        [Markup.button.text("📊 Статистика"), Markup.button.text("👤 Профиль")],
      ]).resize()
    );

    if (partnerId) {
      await bot.telegram.sendMessage(
        partnerId,
        "😔 Собеседник завершил диалог.\n\nНажмите «🔍 Найти собеседника» чтобы найти нового.",
        Markup.keyboard([
          [Markup.button.text("🔍 Найти собеседника")],
          [Markup.button.text("📊 Статистика"), Markup.button.text("👤 Профиль")],
        ]).resize()
      );
    }
  });

  bot.command("next", async (ctx) => {
    const userId = ctx.from.id;

    if (hasSession(userId)) {
      const partnerId = await endSession(userId, "next");

      if (partnerId) {
        await bot.telegram.sendMessage(
          partnerId,
          "😔 Собеседник перешёл к следующему диалогу. Ищем вам нового...",
        );
        await startSearch((text) => bot.telegram.sendMessage(partnerId, text).then(() => {}), partnerId);
      }
    } else {
      removeFromQueue(userId);
    }

    await ctx.reply("🔄 Ищем нового собеседника...");
    await startSearch((text) => ctx.reply(text), userId);
  });

  bot.command("report", async (ctx) => {
    const userId = ctx.from.id;
    const session = getSession(userId);

    if (!session) {
      await ctx.reply("❌ Вы не в диалоге. Жалобу можно подать только во время общения.");
      return;
    }

    const reportedId = session.partner;

    const recentWindow = new Date(Date.now() - 60 * 60 * 1000);
    const [{ value: recentReports }] = await db
      .select({ value: count() })
      .from(reportsTable)
      .where(
        and(
          eq(reportsTable.reportedId, reportedId),
          gte(reportsTable.createdAt, recentWindow)
        )
      );

    await db.insert(reportsTable).values({
      reporterId: userId,
      reportedId: reportedId,
      sessionId: session.sessionId,
      reason: "Жалоба пользователя",
    });

    const totalReports = Number(recentReports) + 1;

    if (totalReports >= 3) {
      const banUntil = new Date(Date.now() + 24 * 60 * 60 * 1000);
      await db
        .update(usersTable)
        .set({ isBanned: true, banUntil })
        .where(eq(usersTable.telegramId, reportedId));

      removeFromQueue(reportedId);
      if (hasSession(reportedId)) {
        removeSession(reportedId);
      }

      try {
        await bot.telegram.sendMessage(
          reportedId,
          "🚫 Вы получили временную блокировку на 24 часа из-за нарушений правил."
        );
      } catch {}

      for (const adminId of ADMIN_IDS) {
        try {
          await bot.telegram.sendMessage(
            adminId,
            `🚨 Авто-бан: пользователь ${reportedId} получил 3+ жалобы за час. Бан на 24ч.`
          );
        } catch {}
      }
    }

    const partnerId = await endSession(userId, "stop");
    await ctx.reply(
      "✅ Жалоба отправлена. Спасибо за сообщение!\n\nДиалог завершён.",
      Markup.keyboard([
        [Markup.button.text("🔍 Найти собеседника")],
        [Markup.button.text("📊 Статистика"), Markup.button.text("👤 Профиль")],
      ]).resize()
    );

    if (partnerId && partnerId !== reportedId) {
      try {
        await bot.telegram.sendMessage(partnerId, "ℹ️ Диалог завершён.");
      } catch {}
    }

    for (const adminId of ADMIN_IDS) {
      try {
        await bot.telegram.sendMessage(
          adminId,
          `📋 Жалоба от ${userId} на ${reportedId} (сессия ${session.sessionId}).`
        );
      } catch {}
    }
  });

  bot.command("like", async (ctx) => {
    const userId = ctx.from.id;
    const session = getSession(userId);

    if (!session) {
      await ctx.reply("❌ Вы не в диалоге. Лайк можно поставить только во время общения.");
      return;
    }

    const partnerId = session.partner;

    const existing = await db
      .select()
      .from(likesTable)
      .where(
        and(
          eq(likesTable.fromUserId, userId),
          eq(likesTable.sessionId, session.sessionId)
        )
      )
      .limit(1);

    if (existing.length > 0) {
      await ctx.reply("❤️ Вы уже поставили лайк в этом диалоге.");
      return;
    }

    await db.insert(likesTable).values({
      fromUserId: userId,
      toUserId: partnerId,
      sessionId: session.sessionId,
    });

    await db
      .update(usersTable)
      .set({ totalLikesReceived: sql`${usersTable.totalLikesReceived} + 1` })
      .where(eq(usersTable.telegramId, partnerId));

    await ctx.reply("❤️ Лайк поставлен!");

    const mutualLike = await db
      .select()
      .from(likesTable)
      .where(
        and(
          eq(likesTable.fromUserId, partnerId),
          eq(likesTable.toUserId, userId),
          eq(likesTable.sessionId, session.sessionId)
        )
      )
      .limit(1);

    if (mutualLike.length > 0) {
      const mutualMsg =
        "🎉 Взаимный лайк! Вам обоим понравилось общение.\n\n" +
        "Хотите обменяться контактами? Ответьте собеседнику 'Да' чтобы поделиться своим @username.";

      await ctx.reply(mutualMsg);
      await bot.telegram.sendMessage(partnerId, mutualMsg);
    } else {
      await bot.telegram.sendMessage(partnerId, "❤️ Собеседник поставил вам лайк!");
    }
  });

  bot.command("profile", async (ctx) => {
    const user = await ensureUser(ctx);
    if (!user) return;

    await ctx.reply(
      `👤 Ваш профиль\n\n` +
      `📝 Описание: ${user.bio || "не задано"}\n` +
      `💬 Всего диалогов: ${user.totalChats}\n` +
      `❤️ Получено лайков: ${user.totalLikesReceived}\n\n` +
      "Чтобы изменить описание, отправьте:\n/setbio Ваш текст"
    );
  });

  bot.hears("👤 Профиль", async (ctx) => {
    const user = await ensureUser(ctx);
    if (!user) return;

    await ctx.reply(
      `👤 Ваш профиль\n\n` +
      `📝 Описание: ${user.bio || "не задано"}\n` +
      `💬 Всего диалогов: ${user.totalChats}\n` +
      `❤️ Получено лайков: ${user.totalLikesReceived}\n\n` +
      "Чтобы изменить описание, отправьте:\n/setbio Ваш текст"
    );
  });

  bot.command("setbio", async (ctx) => {
    const userId = ctx.from.id;
    const bio = ctx.message.text.replace("/setbio", "").trim();

    if (!bio) {
      await ctx.reply("❌ Укажите описание: /setbio Текст о себе");
      return;
    }

    if (bio.length > 200) {
      await ctx.reply("❌ Описание слишком длинное (максимум 200 символов).");
      return;
    }

    if (containsStopWord(bio) || containsAdContent(bio)) {
      await ctx.reply("❌ Описание содержит запрещённый контент.");
      return;
    }

    await db
      .update(usersTable)
      .set({ bio })
      .where(eq(usersTable.telegramId, userId));

    await ctx.reply("✅ Описание обновлено!");
  });

  bot.command("stats", async (ctx) => {
    await ensureUser(ctx);
    const [{ value: totalUsers }] = await db.select({ value: count() }).from(usersTable);
    const [{ value: totalSessions }] = await db.select({ value: count() }).from(sessionsTable);
    const activeDlgs = getActiveSessionsCount();
    const inQueue = getQueueLength();

    await ctx.reply(
      `📊 Статистика бота\n\n` +
      `👥 Всего пользователей: ${totalUsers}\n` +
      `💬 Активных диалогов: ${activeDlgs}\n` +
      `🔍 В очереди поиска: ${inQueue}\n` +
      `📈 Всего диалогов: ${totalSessions}`
    );
  });

  bot.hears("📊 Статистика", async (ctx) => {
    await ensureUser(ctx);
    const [{ value: totalUsers }] = await db.select({ value: count() }).from(usersTable);
    const [{ value: totalSessions }] = await db.select({ value: count() }).from(sessionsTable);
    const activeDlgs = getActiveSessionsCount();
    const inQueue = getQueueLength();

    await ctx.reply(
      `📊 Статистика бота\n\n` +
      `👥 Всего пользователей: ${totalUsers}\n` +
      `💬 Активных диалогов: ${activeDlgs}\n` +
      `🔍 В очереди поиска: ${inQueue}\n` +
      `📈 Всего диалогов: ${totalSessions}`
    );
  });

  bot.command("showbio", async (ctx) => {
    const userId = ctx.from.id;
    const session = getSession(userId);

    if (!session) {
      await ctx.reply("❌ Вы не в диалоге.");
      return;
    }

    const [partner] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.telegramId, session.partner))
      .limit(1);

    if (!partner || !partner.bio) {
      await ctx.reply("ℹ️ Собеседник не заполнил описание.");
    } else {
      await ctx.reply(`📝 О собеседнике:\n\n${partner.bio}`);
    }
  });

  async function relayMessage(ctx: Context, sendFn: (partnerId: number) => Promise<void>): Promise<void> {
    const userId = ctx.from!.id;

    if (await isBanned(userId)) {
      await ctx.reply("🚫 Вы заблокированы.");
      return;
    }

    const session = getSession(userId);
    if (!session) {
      await ctx.reply(
        "❌ Вы не в диалоге. Нажмите «🔍 Найти собеседника» чтобы начать.",
        Markup.keyboard([
          [Markup.button.text("🔍 Найти собеседника")],
          [Markup.button.text("📊 Статистика"), Markup.button.text("👤 Профиль")],
        ]).resize()
      );
      return;
    }

    if (checkSpam(userId)) {
      await ctx.reply("⚠️ Вы отправляете сообщения слишком быстро. Подождите немного.");
      return;
    }

    await sendFn(session.partner);
  }

  bot.on(message("text"), async (ctx) => {
    const userId = ctx.from.id;
    const text = ctx.message.text;

    if (text.startsWith("/")) return;
    if (
      text === "🔍 Найти собеседника" ||
      text === "📊 Статистика" ||
      text === "👤 Профиль"
    )
      return;

    if ("forward_origin" in ctx.message || "forward_date" in ctx.message) {
      await ctx.reply("🚫 Пересылка сообщений из других чатов запрещена.");
      return;
    }

    if (containsAdContent(text)) {
      await ctx.reply("🚫 Ссылки и реклама запрещены в этом боте.");
      return;
    }

    let outText = text;
    if (containsStopWord(text)) {
      outText = censorText(text);

      await db
        .update(usersTable)
        .set({ warnings: sql`${usersTable.warnings} + 1` })
        .where(eq(usersTable.telegramId, userId));

      const [user] = await db
        .select()
        .from(usersTable)
        .where(eq(usersTable.telegramId, userId))
        .limit(1);

      await ctx.reply(`⚠️ Предупреждение: нецензурная лексика запрещена. (${user?.warnings ?? 1}/3)`);

      if ((user?.warnings ?? 0) >= 3) {
        const banUntil = new Date(Date.now() + 6 * 60 * 60 * 1000);
        await db
          .update(usersTable)
          .set({ isBanned: true, banUntil })
          .where(eq(usersTable.telegramId, userId));

        removeFromQueue(userId);
        if (hasSession(userId)) {
          await endSession(userId, "stop");
        }

        await ctx.reply("🚫 Вы получили временную блокировку на 6 часов за нарушение правил.");
        return;
      }
    }

    await relayMessage(ctx, async (partnerId) => {
      await bot.telegram.sendMessage(partnerId, `💬 ${outText}`);
    });
  });

  bot.on(message("photo"), async (ctx) => {
    if ("forward_origin" in ctx.message || "forward_date" in ctx.message) {
      await ctx.reply("🚫 Пересылка сообщений из других чатов запрещена.");
      return;
    }
    await relayMessage(ctx, async (partnerId) => {
      const photo = ctx.message.photo[ctx.message.photo.length - 1];
      const caption = ctx.message.caption ? `📷 ${ctx.message.caption}` : undefined;
      await bot.telegram.sendPhoto(partnerId, photo.file_id, { caption });
    });
  });

  bot.on(message("video"), async (ctx) => {
    if ("forward_origin" in ctx.message || "forward_date" in ctx.message) {
      await ctx.reply("🚫 Пересылка сообщений из других чатов запрещена.");
      return;
    }
    await relayMessage(ctx, async (partnerId) => {
      const caption = ctx.message.caption ? `🎥 ${ctx.message.caption}` : undefined;
      await bot.telegram.sendVideo(partnerId, ctx.message.video.file_id, { caption });
    });
  });

  bot.on(message("voice"), async (ctx) => {
    if ("forward_origin" in ctx.message || "forward_date" in ctx.message) {
      await ctx.reply("🚫 Пересылка сообщений из других чатов запрещена.");
      return;
    }
    await relayMessage(ctx, async (partnerId) => {
      await bot.telegram.sendVoice(partnerId, ctx.message.voice.file_id);
    });
  });

  bot.on(message("sticker"), async (ctx) => {
    if ("forward_origin" in ctx.message || "forward_date" in ctx.message) {
      await ctx.reply("🚫 Пересылка сообщений из других чатов запрещена.");
      return;
    }
    await relayMessage(ctx, async (partnerId) => {
      await bot.telegram.sendSticker(partnerId, ctx.message.sticker.file_id);
    });
  });

  bot.on(message("document"), async (ctx) => {
    if ("forward_origin" in ctx.message || "forward_date" in ctx.message) {
      await ctx.reply("🚫 Пересылка сообщений из других чатов запрещена.");
      return;
    }
    await relayMessage(ctx, async (partnerId) => {
      const caption = ctx.message.caption ? `📎 ${ctx.message.caption}` : undefined;
      await bot.telegram.sendDocument(partnerId, ctx.message.document.file_id, { caption });
    });
  });

  bot.on(message("video_note"), async (ctx) => {
    await ctx.reply("🚫 Видеосообщения (кружочки) запрещены в этом боте.");
  });

  bot.on(message("audio"), async (ctx) => {
    if ("forward_origin" in ctx.message || "forward_date" in ctx.message) {
      await ctx.reply("🚫 Пересылка сообщений из других чатов запрещена.");
      return;
    }
    await relayMessage(ctx, async (partnerId) => {
      await bot.telegram.sendAudio(partnerId, ctx.message.audio.file_id);
    });
  });

  function isAdmin(userId: number): boolean {
    return ADMIN_IDS.includes(userId);
  }

  bot.command("banid", async (ctx) => {
    if (!isAdmin(ctx.from.id)) {
      await ctx.reply("❌ Нет доступа.");
      return;
    }
    const parts = ctx.message.text.split(" ");
    const targetId = Number(parts[1]);
    const permanent = parts[2] === "perm";

    if (!targetId || isNaN(targetId)) {
      await ctx.reply("Использование: /banid <telegram_id> [perm]\nПример: /banid 123456789\nПример (перм): /banid 123456789 perm");
      return;
    }

    const banUntil = permanent ? null : new Date(Date.now() + 24 * 60 * 60 * 1000);

    await db
      .insert(usersTable)
      .values({ telegramId: targetId, isBanned: true, banPermanent: permanent, banUntil })
      .onConflictDoUpdate({
        target: usersTable.telegramId,
        set: { isBanned: true, banPermanent: permanent, banUntil },
      });

    removeFromQueue(targetId);
    if (hasSession(targetId)) {
      const partnerId = await endSession(targetId, "stop");
      if (partnerId) {
        try { await bot.telegram.sendMessage(partnerId, "ℹ️ Диалог завершён."); } catch {}
      }
    }

    try {
      await bot.telegram.sendMessage(
        targetId,
        permanent
          ? "🚫 Вы заблокированы навсегда за нарушение правил."
          : "🚫 Вы заблокированы на 24 часа за нарушение правил."
      );
    } catch {}

    await ctx.reply(`✅ Пользователь ${targetId} заблокирован${permanent ? " навсегда" : " на 24 часа"}.`);
  });

  bot.command("unbanid", async (ctx) => {
    if (!isAdmin(ctx.from.id)) {
      await ctx.reply("❌ Нет доступа.");
      return;
    }
    const parts = ctx.message.text.split(" ");
    const targetId = Number(parts[1]);

    if (!targetId || isNaN(targetId)) {
      await ctx.reply("Использование: /unbanid <telegram_id>");
      return;
    }

    await db
      .update(usersTable)
      .set({ isBanned: false, banPermanent: false, banUntil: null })
      .where(eq(usersTable.telegramId, targetId));

    try {
      await bot.telegram.sendMessage(targetId, "✅ Ваша блокировка снята. Вы можете пользоваться ботом.");
    } catch {}

    await ctx.reply(`✅ Пользователь ${targetId} разблокирован.`);
  });

  bot.command("finduser", async (ctx) => {
    if (!isAdmin(ctx.from.id)) {
      await ctx.reply("❌ Нет доступа.");
      return;
    }
    const parts = ctx.message.text.split(" ");
    const username = parts[1]?.replace("@", "").toLowerCase();

    if (!username) {
      await ctx.reply("Использование: /finduser @username");
      return;
    }

    const users = await db
      .select()
      .from(usersTable)
      .where(eq(sql`lower(${usersTable.username})`, username))
      .limit(5);

    if (users.length === 0) {
      await ctx.reply(`❌ Пользователь @${username} не найден в базе.`);
      return;
    }

    const lines = users.map(
      (u) =>
        `ID: ${u.telegramId}\n@${u.username ?? "—"}\nБан: ${u.isBanned ? (u.banPermanent ? "перм" : "врем") : "нет"}\nДиалогов: ${u.totalChats}\nЛайков: ${u.totalLikesReceived}`
    );
    await ctx.reply(`🔍 Найдено:\n\n${lines.join("\n\n")}`);
  });

  bot.command("adminhelp", async (ctx) => {
    if (!isAdmin(ctx.from.id)) {
      await ctx.reply("❌ Нет доступа.");
      return;
    }
    await ctx.reply(
      "🛠 Админ-команды:\n\n" +
      "/banid <id> — бан на 24ч\n" +
      "/banid <id> perm — перманентный бан\n" +
      "/unbanid <id> — снять бан\n" +
      "/finduser @username — найти ID пользователя по юзернейму\n" +
      "/adminhelp — эта справка\n\n" +
      "Чтобы забанить @Rick666u:\n" +
      "1. Отправьте /finduser @rick666u\n" +
      "2. Скопируйте ID и используйте /banid <ID> perm"
    );
  });

  bot.catch((err, ctx) => {
    logger.error({ err, userId: ctx.from?.id }, "Bot error");
  });

  return bot;
}
