type UserId = number;

const waitingQueue: UserId[] = [];

export function addToQueue(userId: UserId): void {
  if (!waitingQueue.includes(userId)) {
    waitingQueue.push(userId);
  }
}

export function removeFromQueue(userId: UserId): void {
  const idx = waitingQueue.indexOf(userId);
  if (idx !== -1) {
    waitingQueue.splice(idx, 1);
  }
}

export function findPartner(userId: UserId): UserId | null {
  const idx = waitingQueue.findIndex((id) => id !== userId);
  if (idx === -1) return null;
  const partnerId = waitingQueue[idx];
  waitingQueue.splice(idx, 1);
  removeFromQueue(userId);
  return partnerId;
}

export function getQueueLength(): number {
  return waitingQueue.length;
}

export function isInQueue(userId: UserId): boolean {
  return waitingQueue.includes(userId);
}
