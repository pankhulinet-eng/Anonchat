type UserId = number;

interface ActiveSession {
  sessionId: number;
  partner: UserId;
  startedAt: Date;
}

const activeSessions = new Map<UserId, ActiveSession>();

export function setSession(userId: UserId, session: ActiveSession): void {
  activeSessions.set(userId, session);
}

export function getSession(userId: UserId): ActiveSession | undefined {
  return activeSessions.get(userId);
}

export function removeSession(userId: UserId): void {
  activeSessions.delete(userId);
}

export function hasSession(userId: UserId): boolean {
  return activeSessions.has(userId);
}

export function getActiveSessionsCount(): number {
  return activeSessions.size / 2;
}

export type { ActiveSession };
