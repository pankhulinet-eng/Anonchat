const STOP_WORDS = [
  "хуй", "пизда", "ебать", "блядь", "сука", "пиздец", "залупа", "мудак",
  "ублюдок", "шлюха", "проститутка", "пидор", "педик", "гандон", "ёбаный",
  "fuck", "shit", "bitch", "asshole", "cunt", "nigger", "faggot", "whore",
  "cock", "dick", "pussy", "bastard",
];

const AD_PATTERNS = [
  /https?:\/\//i,
  /t\.me\//i,
  /telegram\.me\//i,
  /wa\.me\//i,
  /vk\.com\//i,
  /instagram\.com\//i,
  /купить|продам|заработок|деньги|реклама|казино|ставки|крипта|инвест/i,
  /@[a-zA-Z0-9_]{5,}/,
];

export function containsStopWord(text: string): boolean {
  const lower = text.toLowerCase();
  return STOP_WORDS.some((word) => lower.includes(word));
}

export function containsAdContent(text: string): boolean {
  return AD_PATTERNS.some((pattern) => pattern.test(text));
}

export function censorText(text: string): string {
  let result = text;
  for (const word of STOP_WORDS) {
    const regex = new RegExp(word, "gi");
    result = result.replace(regex, "*".repeat(word.length));
  }
  return result;
}
