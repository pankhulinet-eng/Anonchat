import { VK, Keyboard } from "vk-io";
import { db } from "@workspace/db";
import {
  usersTable,
  sessionsTable,
  reportsTable,
  likesTable,
} from "@workspace/db";
import { eq, and, sql, count, gte } from "drizzle-orm";
import { logger } from "../lib/logger";
import {
  addToQueue,
  removeFromQueue,
  findPartner,
  getQueueLength,
  isInQueue,
} from "./queue";
import {
  setSession,
  getSession,
  removeSession,
  hasSession,
  getActiveSessionsCount,
} from "./sessions";
import { containsStopWord, containsAdContent, censorText } from "./stopwords";
import { checkSpam } from "./antispam";

const ADMIN_IDS: number[] = (process.env.ADMIN_IDS || "")
  .split(",")
  .map(Number)
  .filter(Boolean);

// Клавиатура главного меню
const MAIN_KEYBOARD = Keyboard.builder()
  .textButton({ label: "🔍 Найти собеседника", color: Keyboard.PRIMARY_COLOR })
  .row()
  .textButton({ label: "📊 Статистика", color: Keyboard.SECONDARY_COLOR })
  .textButton({ label: "👤 Профиль", color: Keyboard.SECONDARY_COLOR })
  .inline(false);

// Клавиатура во время диалога
const CHAT_KEYBOARD = Keyboard.builder()
  .textButton({ label: "❤️ Лайк", color: Keyboard.POSITIVE_COLOR })
  .textButton({ label: "👎 Дизлайк", color: Keyboard.NEGATIVE_COLOR })
  .row()
  .textButton({ label: "🛑 Закончить диалог", color: Keyboard.SECONDARY_COLOR })
  .inline(false);

// Клавиатура профиля
const PROFILE_KEYBOARD = Keyboard.builder()
  .textButton({ label: "✏️ Изменить описание", color: Keyboard.PRIMARY_COLOR })
  .row()
  .textButton({ label: "◀️ Назад", color: Keyboard.SECONDARY_COLOR })
  .inline(false);

type KbType = "main" | "chat" | "profile" | "none";

async function sendMsg(
  vk: VK,
  peerId: number,
  message: string,
  kb: KbType = "none"
): Promise<void> {
  const keyboard =
    kb === "main"
      ? MAIN_KEYBOARD.toString()
      : kb === "chat"
      ? CHAT_KEYBOARD.toString()
      : kb === "profile"
      ? PROFILE_KEYBOARD.toString()
      : undefined;

  await vk.api.messages.send({
    peer_id: peerId,
    message,
    random_id: Math.floor(Math.random() * 1e9),
    ...(keyboard ? { keyboard } : {}),
  });
}

export async function createVkBot(): Promise<VK> {
  const token = process.env.VK_GROUP_TOKEN;
  if (!token) throw new Error("VK_GROUP_TOKEN is not set");

  // Resolve group ID — required for community (group) long poll.
  // Without pollingGroupId vk-io falls back to user long poll and
  // community messages are never delivered.
  let groupId: number;
  if (process.env.VK_GROUP_ID) {
    groupId = Number(process.env.VK_GROUP_ID);
    if (!groupId || isNaN(groupId)) throw new Error("VK_GROUP_ID must be a valid number");
    logger.info({ groupId }, "VK group ID loaded from env");
  } else {
    const tempVk = new VK({ token });
    const result = await tempVk.api.groups.getById({});
    const firstGroup = result.groups?.[0];
    if (!firstGroup?.id) {
      throw new Error(
        "Could not auto-detect VK group ID from token. " +
        "Please set VK_GROUP_ID environment variable to your community's numeric ID."
      );
    }
    groupId = firstGroup.id;
    logger.info({ groupId }, "VK group ID auto-detected");
  }

  const vk = new VK({ token, pollingGroupId: groupId });

  // Пользователи, ожидающие ввода нового описания
  const awaitingBio = new Set<number>();

  async function ensureUser(peerId: number, username?: string): Promise<typeof usersTable.$inferSelect | null> {
    const existing = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.telegramId, peerId))
      .limit(1);

    if (existing.length > 0) return existing[0];

    const [created] = await db
      .insert(usersTable)
      .values({ telegramId: peerId, username: username ?? null })
      .returning();

    return created;
  }

  async function isBanned(userId: number): Promise<boolean> {
    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.telegramId, userId))
      .limit(1);

    if (!user) return false;
    if (user.banPermanent) return true;
    if (user.banUntil && user.banUntil > new Date()) return true;
    return false;
  }

  async function endSession(userId: number): Promise<number | null> {
    const session = getSession(userId);
    if (!session) return null;

    const { partner, sessionId } = session;
    removeSession(userId);
    removeSession(partner);

    await db
      .update(sessionsTable)
      .set({ isActive: false, endedAt: new Date() })
      .where(eq(sessionsTable.id, sessionId));

    return partner;
  }

  async function startSearch(userId: number): Promise<void> {
    if (await isBanned(userId)) {
      await sendMsg(vk, userId, "🚫 Вы заблокированы и не можете пользоваться ботом.", "main");
      return;
    }
    if (hasSession(userId)) {
      await sendMsg(vk, userId, "💬 Вы уже в диалоге. Используйте кнопку «🛑 Закончить диалог».");
      return;
    }
    if (isInQueue(userId)) {
      await sendMsg(vk, userId, "🔍 Вы уже в очереди поиска.");
      return;
    }

    const partnerId = findPartner(userId);

    if (partnerId !== null) {
      const [session] = await db
        .insert(sessionsTable)
        .values({ user1Id: userId, user2Id: partnerId })
        .returning();

      setSession(userId, { sessionId: session.id, partner: partnerId, startedAt: new Date() });
      setSession(partnerId, { sessionId: session.id, partner: userId, startedAt: new Date() });

      await db.update(usersTable).set({ totalChats: sql`${usersTable.totalChats} + 1` }).where(eq(usersTable.telegramId, userId));
      await db.update(usersTable).set({ totalChats: sql`${usersTable.totalChats} + 1` }).where(eq(usersTable.telegramId, partnerId));

      const connectMsg = "🎉 Собеседник найден! Начинайте общение.";

      await sendMsg(vk, userId, connectMsg, "chat");
      await sendMsg(vk, partnerId, connectMsg, "chat");
    } else {
      addToQueue(userId);
      await sendMsg(vk, userId, `🔍 Ищем собеседника... В очереди: ${getQueueLength()} чел.\n\nНажмите «🛑 Закончить диалог» чтобы отменить поиск.`);
    }
  }

  async function doLike(userId: number): Promise<void> {
    const session = getSession(userId);
    if (!session) {
      await sendMsg(vk, userId, "❌ Вы не в диалоге. Лайк можно поставить только во время общения.");
      return;
    }
    const partnerId = session.partner;
    const existing = await db.select().from(likesTable).where(and(eq(likesTable.fromUserId, userId), eq(likesTable.sessionId, session.sessionId))).limit(1);
    if (existing.length > 0) {
      await sendMsg(vk, userId, "❤️ Вы уже поставили лайк в этом диалоге.");
      return;
    }
    await db.insert(likesTable).values({ fromUserId: userId, toUserId: partnerId, sessionId: session.sessionId });
    await db.update(usersTable).set({ totalLikesReceived: sql`${usersTable.totalLikesReceived} + 1` }).where(eq(usersTable.telegramId, partnerId));
    await sendMsg(vk, userId, "❤️ Лайк поставлен!");

    const mutualLike = await db.select().from(likesTable).where(and(eq(likesTable.fromUserId, partnerId), eq(likesTable.toUserId, userId), eq(likesTable.sessionId, session.sessionId))).limit(1);
    if (mutualLike.length > 0) {
      const mutualMsg = "🎉 Взаимный лайк! Вам обоим понравилось.\n\nХотите обменяться контактами? Напишите собеседнику об этом напрямую.";
      await sendMsg(vk, userId, mutualMsg);
      await sendMsg(vk, partnerId, mutualMsg);
    } else {
      await sendMsg(vk, partnerId, "❤️ Собеседник поставил вам лайк!");
    }
  }

  async function showProfile(vk: VK, userId: number): Promise<void> {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.telegramId, userId)).limit(1);
    await sendMsg(
      vk,
      userId,
      `👤 Ваш профиль\n\n📝 Описание: ${user?.bio || "не задано"}\n💬 Всего диалогов: ${user?.totalChats ?? 0}\n❤️ Получено лайков: ${user?.totalLikesReceived ?? 0}`,
      "profile"
    );
  }

  vk.updates.on("message_new", async (ctx) => {
    if (ctx.isOutbox) return;

    const userId = ctx.peerId;
    const text = (ctx.text ?? "").trim();

    await ensureUser(userId);

    if (await isBanned(userId)) {
      await sendMsg(vk, userId, "🚫 Вы заблокированы.");
      return;
    }

    if (ctx.hasForwards || (ctx as any).forwards?.length > 0) {
      await sendMsg(vk, userId, "🚫 Пересылка сообщений запрещена в этом боте.");
      return;
    }

    const lower = text.toLowerCase();

    // --- Ожидание ввода нового описания ---
    if (awaitingBio.has(userId)) {
      awaitingBio.delete(userId);
      if (!text || lower.startsWith("/")) {
        await sendMsg(vk, userId, "❌ Описание не изменено.", "profile");
        return;
      }
      if (text.length > 200) {
        await sendMsg(vk, userId, "❌ Описание слишком длинное (максимум 200 символов). Попробуйте ещё раз.", "profile");
        return;
      }
      if (containsStopWord(text) || containsAdContent(text)) {
        await sendMsg(vk, userId, "❌ Описание содержит запрещённый контент.", "profile");
        return;
      }
      await db.update(usersTable).set({ bio: text }).where(eq(usersTable.telegramId, userId));
      const [updated] = await db.select().from(usersTable).where(eq(usersTable.telegramId, userId)).limit(1);
      await sendMsg(
        vk,
        userId,
        `✅ Описание обновлено!\n\n👤 Ваш профиль\n\n📝 Описание: ${updated?.bio || "не задано"}\n💬 Всего диалогов: ${updated?.totalChats ?? 0}\n❤️ Получено лайков: ${updated?.totalLikesReceived ?? 0}`,
        "profile"
      );
      return;
    }

    // --- Кнопки профиля ---
    if (lower === "✏️ изменить описание") {
      awaitingBio.add(userId);
      await sendMsg(vk, userId, "✏️ Напишите своё новое описание (до 200 символов):");
      return;
    }

    if (lower === "◀️ назад") {
      await sendMsg(vk, userId, "Главное меню", "main");
      return;
    }

    // --- Кнопки чата ---
    if (lower === "❤️ лайк" || lower === "/like") {
      await doLike(userId);
      return;
    }

    if (lower === "👎 дизлайк") {
      // Дизлайк = перейти к следующему собеседнику
      if (hasSession(userId)) {
        const partnerId = await endSession(userId);
        if (partnerId) {
          await sendMsg(vk, partnerId, "😔 Собеседник перешёл к следующему. Ищем вам нового...", "main");
          await startSearch(partnerId);
        }
      } else {
        removeFromQueue(userId);
      }
      await sendMsg(vk, userId, "🔄 Ищем нового собеседника...");
      await startSearch(userId);
      return;
    }

    if (lower === "🛑 закончить диалог" || lower === "/stop") {
      awaitingBio.delete(userId);
      removeFromQueue(userId);
      if (!hasSession(userId)) {
        await sendMsg(vk, userId, "✅ Вы не в диалоге и не в очереди поиска.", "main");
        return;
      }
      const partnerId = await endSession(userId);
      await sendMsg(vk, userId, "🛑 Диалог завершён.\n\nНажмите «🔍 Найти собеседника» чтобы начать новый.", "main");
      if (partnerId) {
        await sendMsg(vk, partnerId, "😔 Собеседник завершил диалог.\n\nНажмите «🔍 Найти собеседника» чтобы найти нового.", "main");
      }
      return;
    }

    // --- Главное меню ---
    if (lower === "/start" || lower === "начать") {
      await sendMsg(
        vk,
        userId,
        "👋 Добро пожаловать в анонимный чат!\n\n" +
        "Здесь вы можете анонимно общаться с людьми.\n\n" +
        "Нажмите «🔍 Найти собеседника» чтобы начать!",
        "main"
      );
      return;
    }

    if (lower === "🔍 найти собеседника" || lower === "/find" || lower === "/search") {
      await startSearch(userId);
      return;
    }

    if (lower === "/next") {
      if (hasSession(userId)) {
        const partnerId = await endSession(userId);
        if (partnerId) {
          await sendMsg(vk, partnerId, "😔 Собеседник перешёл к следующему. Ищем вам нового...", "main");
          await startSearch(partnerId);
        }
      } else {
        removeFromQueue(userId);
      }
      await sendMsg(vk, userId, "🔄 Ищем нового собеседника...");
      await startSearch(userId);
      return;
    }

    if (lower === "/help") {
      await sendMsg(
        vk,
        userId,
        "📖 Помощь\n\n" +
        "Нажмите «🔍 Найти собеседника» чтобы начать диалог.\n\n" +
        "Во время диалога:\n" +
        "❤️ Лайк — понравился собеседник\n" +
        "👎 Дизлайк — найти следующего\n" +
        "🛑 Закончить диалог — выйти\n\n" +
        "Жалоба на собеседника: /report\n\n" +
        "⚠️ Правила:\n" +
        "• Запрещены ссылки и реклама\n" +
        "• Запрещена нецензурная лексика\n" +
        "• 3 жалобы = автоматический бан",
        "main"
      );
      return;
    }

    if (lower === "/report") {
      const session = getSession(userId);
      if (!session) {
        await sendMsg(vk, userId, "❌ Вы не в диалоге. Жалобу можно подать только во время общения.");
        return;
      }
      const reportedId = session.partner;
      const recentWindow = new Date(Date.now() - 60 * 60 * 1000);
      const [{ value: recentReports }] = await db
        .select({ value: count() })
        .from(reportsTable)
        .where(and(eq(reportsTable.reportedId, reportedId), gte(reportsTable.createdAt, recentWindow)));

      await db.insert(reportsTable).values({ reporterId: userId, reportedId, sessionId: session.sessionId, reason: "Жалоба пользователя" });

      const totalReports = Number(recentReports) + 1;
      if (totalReports >= 3) {
        const banUntil = new Date(Date.now() + 24 * 60 * 60 * 1000);
        await db.update(usersTable).set({ isBanned: true, banUntil }).where(eq(usersTable.telegramId, reportedId));
        removeFromQueue(reportedId);
        if (hasSession(reportedId)) removeSession(reportedId);
        try { await sendMsg(vk, reportedId, "🚫 Вы получили блокировку на 24 часа из-за нарушений.", "main"); } catch {}
        for (const adminId of ADMIN_IDS) {
          try { await sendMsg(vk, adminId, `🚨 Авто-бан: пользователь ${reportedId} — 3+ жалоб за час.`); } catch {}
        }
      }

      const partnerId = await endSession(userId);
      await sendMsg(vk, userId, "✅ Жалоба отправлена. Диалог завершён.", "main");
      if (partnerId && partnerId !== reportedId) {
        try { await sendMsg(vk, partnerId, "ℹ️ Диалог завершён.", "main"); } catch {}
      }
      for (const adminId of ADMIN_IDS) {
        try { await sendMsg(vk, adminId, `📋 Жалоба от ${userId} на ${reportedId} (сессия ${session.sessionId}).`); } catch {}
      }
      return;
    }

    if (lower === "/profile" || lower === "👤 профиль") {
      await showProfile(vk, userId);
      return;
    }

    if (lower === "/stats" || lower === "📊 статистика") {
      const [{ value: totalUsers }] = await db.select({ value: count() }).from(usersTable);
      const [{ value: totalSessions }] = await db.select({ value: count() }).from(sessionsTable);
      await sendMsg(
        vk,
        userId,
        `📊 Статистика бота\n\n👥 Всего пользователей: ${totalUsers}\n💬 Активных диалогов: ${getActiveSessionsCount()}\n🔍 В очереди: ${getQueueLength()}\n📈 Всего диалогов: ${totalSessions}`,
        "main"
      );
      return;
    }

    if (lower === "/showbio") {
      const session = getSession(userId);
      if (!session) { await sendMsg(vk, userId, "❌ Вы не в диалоге."); return; }
      const [partner] = await db.select().from(usersTable).where(eq(usersTable.telegramId, session.partner)).limit(1);
      await sendMsg(vk, userId, partner?.bio ? `📝 О собеседнике:\n\n${partner.bio}` : "ℹ️ Собеседник не заполнил описание.");
      return;
    }

    if (lower.startsWith("/setbio ")) {
      const bio = text.slice("/setbio ".length).trim();
      if (!bio) { await sendMsg(vk, userId, "❌ Укажите описание: /setbio Текст о себе"); return; }
      if (bio.length > 200) { await sendMsg(vk, userId, "❌ Описание слишком длинное (максимум 200 символов)."); return; }
      if (containsStopWord(bio) || containsAdContent(bio)) { await sendMsg(vk, userId, "❌ Описание содержит запрещённый контент."); return; }
      await db.update(usersTable).set({ bio }).where(eq(usersTable.telegramId, userId));
      await sendMsg(vk, userId, "✅ Описание обновлено!");
      return;
    }

    // --- Админ-команды ---
    if (ADMIN_IDS.includes(userId)) {
      if (lower.startsWith("/banid ")) {
        const parts = text.split(" ");
        const targetId = Number(parts[1]);
        const permanent = parts[2] === "perm";
        if (!targetId || isNaN(targetId)) { await sendMsg(vk, userId, "Использование: /banid <id> [perm]"); return; }
        const banUntil = permanent ? null : new Date(Date.now() + 24 * 60 * 60 * 1000);
        await db.insert(usersTable).values({ telegramId: targetId, isBanned: true, banPermanent: permanent, banUntil })
          .onConflictDoUpdate({ target: usersTable.telegramId, set: { isBanned: true, banPermanent: permanent, banUntil } });
        removeFromQueue(targetId);
        if (hasSession(targetId)) { const p = await endSession(targetId); if (p) { try { await sendMsg(vk, p, "ℹ️ Диалог завершён.", "main"); } catch {} } }
        try { await sendMsg(vk, targetId, permanent ? "🚫 Вы заблокированы навсегда." : "🚫 Вы заблокированы на 24 часа."); } catch {}
        await sendMsg(vk, userId, `✅ Пользователь ${targetId} заблокирован${permanent ? " навсегда" : " на 24ч"}.`);
        return;
      }

      if (lower.startsWith("/unbanid ")) {
        const targetId = Number(text.split(" ")[1]);
        if (!targetId || isNaN(targetId)) { await sendMsg(vk, userId, "Использование: /unbanid <id>"); return; }
        await db.update(usersTable).set({ isBanned: false, banPermanent: false, banUntil: null }).where(eq(usersTable.telegramId, targetId));
        try { await sendMsg(vk, targetId, "✅ Ваша блокировка снята."); } catch {}
        await sendMsg(vk, userId, `✅ Пользователь ${targetId} разблокирован.`);
        return;
      }

      if (lower.startsWith("/finduser ")) {
        const username = text.split(" ")[1]?.replace("@", "").toLowerCase();
        if (!username) { await sendMsg(vk, userId, "Использование: /finduser @username"); return; }
        const users = await db.select().from(usersTable).where(eq(sql`lower(${usersTable.username})`, username)).limit(5);
        if (users.length === 0) { await sendMsg(vk, userId, `❌ Пользователь @${username} не найден.`); return; }
        const lines = users.map(u => `ID: ${u.telegramId}\n@${u.username ?? "—"}\nБан: ${u.isBanned ? (u.banPermanent ? "перм" : "врем") : "нет"}\nДиалогов: ${u.totalChats}`);
        await sendMsg(vk, userId, `🔍 Найдено:\n\n${lines.join("\n\n")}`);
        return;
      }

      if (lower === "/adminhelp") {
        await sendMsg(vk, userId, "🛠 Админ-команды:\n\n/banid <id> — бан 24ч\n/banid <id> perm — перм бан\n/unbanid <id> — разбан\n/finduser @username — найти ID");
        return;
      }
    }

    // --- Пересылка в сессии ---
    const session = getSession(userId);

    if (!session) {
      if (text) {
        await sendMsg(vk, userId, "❌ Вы не в диалоге. Нажмите «🔍 Найти собеседника».", "main");
      }
      return;
    }

    if (checkSpam(userId)) {
      await sendMsg(vk, userId, "⚠️ Слишком быстро. Подождите немного.");
      return;
    }

    if (text) {
      if (containsAdContent(text)) {
        await sendMsg(vk, userId, "🚫 Ссылки и реклама запрещены.");
        return;
      }

      let outText = text;
      if (containsStopWord(text)) {
        outText = censorText(text);
        await db.update(usersTable).set({ warnings: sql`${usersTable.warnings} + 1` }).where(eq(usersTable.telegramId, userId));
        const [user] = await db.select().from(usersTable).where(eq(usersTable.telegramId, userId)).limit(1);
        await sendMsg(vk, userId, `⚠️ Предупреждение: нецензурная лексика запрещена. (${user?.warnings ?? 1}/3)`);
        if ((user?.warnings ?? 0) >= 3) {
          const banUntil = new Date(Date.now() + 6 * 60 * 60 * 1000);
          await db.update(usersTable).set({ isBanned: true, banUntil }).where(eq(usersTable.telegramId, userId));
          removeFromQueue(userId);
          if (hasSession(userId)) await endSession(userId);
          await sendMsg(vk, userId, "🚫 Вы заблокированы на 6 часов.", "main");
          return;
        }
      }

      await sendMsg(vk, session.partner, `💬 ${outText}`);
    }

    if (ctx.hasAttachments()) {
      for (const attachment of ctx.attachments) {
        const type = attachment.type;

        if (type === "video_note" as never) {
          await sendMsg(vk, userId, "🚫 Видеосообщения (кружочки) запрещены.");
          continue;
        }

        try {
          await vk.api.messages.send({
            peer_id: session.partner,
            message: "",
            random_id: Math.floor(Math.random() * 1e9),
            attachment: attachment.toString(),
          });
        } catch (err) {
          logger.error({ err }, "Failed to relay attachment");
        }
      }
    }
  });

  return vk;
}
