import app from "./app";
import { logger } from "./lib/logger";
import { createVkBot } from "./bot/vk";
import type { VK } from "vk-io";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error("PORT environment variable is required but was not provided.");
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }
  logger.info({ port }, "Server listening");
});

let vkInstance: VK | null = null;

createVkBot()
  .then((vk) => {
    vkInstance = vk;
    return vk.updates.startPolling();
  })
  .then(() => {
    logger.info("VK bot started (long polling)");
  })
  .catch((err) => {
    logger.error({ err }, "Failed to start VK bot");
    process.exit(1);
  });

process.once("SIGINT", () => {
  vkInstance?.updates.stop().finally(() => process.exit(0));
});
process.once("SIGTERM", () => {
  vkInstance?.updates.stop().finally(() => process.exit(0));
});
