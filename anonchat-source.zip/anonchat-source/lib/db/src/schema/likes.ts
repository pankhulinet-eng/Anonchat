import { pgTable, serial, bigint, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const likesTable = pgTable("likes", {
  id: serial("id").primaryKey(),
  fromUserId: bigint("from_user_id", { mode: "number" }).notNull(),
  toUserId: bigint("to_user_id", { mode: "number" }).notNull(),
  sessionId: integer("session_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertLikeSchema = createInsertSchema(likesTable).omit({ id: true, createdAt: true });
export type InsertLike = z.infer<typeof insertLikeSchema>;
export type Like = typeof likesTable.$inferSelect;
