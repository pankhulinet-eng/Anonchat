import { pgTable, bigint, text, boolean, integer, timestamp, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  telegramId: bigint("telegram_id", { mode: "number" }).notNull().unique(),
  username: text("username"),
  bio: text("bio"),
  isBanned: boolean("is_banned").notNull().default(false),
  banUntil: timestamp("ban_until"),
  banPermanent: boolean("ban_permanent").notNull().default(false),
  warnings: integer("warnings").notNull().default(0),
  totalChats: integer("total_chats").notNull().default(0),
  totalLikesReceived: integer("total_likes_received").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(usersTable).omit({ id: true, createdAt: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
