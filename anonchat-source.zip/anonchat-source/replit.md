# AnonChat Bot

Анонимный Telegram чат-бот для общения между случайными пользователями.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — запустить API-сервер + Telegram-бот (порт 5000)
- `pnpm run typecheck` — полная проверка типов
- `pnpm run build` — сборка всех пакетов
- `pnpm --filter @workspace/db run push` — применить изменения схемы БД (только dev)
- Required env: `DATABASE_URL` — строка подключения PostgreSQL
- Required secret: `TELEGRAM_BOT_TOKEN` — токен бота из @BotFather
- Optional env: `ADMIN_IDS` — comma-separated список Telegram ID администраторов

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Bot: Telegraf 4
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- Build: esbuild (CJS bundle)

## Where things live

- `lib/db/src/schema/` — схема БД: users, sessions, reports, likes
- `artifacts/api-server/src/bot/` — логика бота
  - `index.ts` — основной файл бота (все команды и хендлеры)
  - `queue.ts` — очередь ожидания собеседника (in-memory)
  - `sessions.ts` — активные сессии (in-memory)
  - `stopwords.ts` — фильтр стоп-слов и рекламы
  - `antispam.ts` — анти-спам по скорости сообщений
- `artifacts/api-server/src/index.ts` — точка входа (Express + bot.launch)

## Architecture decisions

- **In-memory очередь и сессии**: Для скорости. При рестарте сервера все активные чаты сбрасываются — принятый трейдоф для анонимности.
- **Пересылка через bot**: Все сообщения проксируются ботом, реальные профили никогда не раскрываются.
- **Авто-бан по репортам**: 3+ жалобы за час = временный бан 24ч автоматически.
- **Очистка истории**: После завершения сессии in-memory данные удаляются немедленно. В БД хранятся только агрегированные данные (счётчики), а не содержимое сообщений.

## Product

- Пользователь нажимает «🔍 Найти собеседника» → попадает в очередь
- При нахождении пары — начинается анонимный диалог
- Поддержка: текст, фото, видео, голосовые, стикеры, файлы, видеозаметки
- /next — следующий собеседник, /stop — выйти, /report — жалоба, /like — лайк
- Взаимные лайки — предложение обменяться контактами
- Профиль с bio, статистика онлайн

## Gotchas

- `ADMIN_IDS` нужно задать чтобы получать уведомления о репортах и банах
- Bot использует long polling — не нужен webhook или публичный URL
- После рестарта сервера все in-memory очереди сбрасываются

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
